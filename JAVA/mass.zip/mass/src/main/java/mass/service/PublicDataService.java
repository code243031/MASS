package mass.service;

public interface PublicDataService {
	public void dataInquiry(int no) throws Exception;
}
