package mass.service;

public interface SystemService {
	public void dataInquiry(int no) throws Exception;
}
