package mass.service;

import org.springframework.stereotype.Service;

@Service
public class SystemServiceImpl implements SystemService {
	// 데이터 조회
	public void dataInquiry(int no) throws Exception{
	};
}
